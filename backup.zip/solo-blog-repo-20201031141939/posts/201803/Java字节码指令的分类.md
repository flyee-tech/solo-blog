title: Java字节码指令的分类
date: '2018-03-28 23:36:30'
updated: '2018-03-28 23:36:30'
tags: [JVM, Java]
permalink: /articles/2018/03/28/1522251390139.html
---
**具有阅读字节码指令的能力对于理解Java语义有着重要的意义**

<!-- more -->

![Xnip2018-03-87_15-35-04.jpg](http://peierlong-blog.oss-cn-hongkong.aliyuncs.com/Xnip2018-03-87_15-35-04.jpg)