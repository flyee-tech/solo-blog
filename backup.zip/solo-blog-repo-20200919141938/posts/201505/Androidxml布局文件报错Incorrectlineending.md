title: Android xml布局文件报错Incorrect line ending
date: '2015-05-18 02:02:01'
updated: '2015-05-18 02:02:01'
tags: [Android]
permalink: /articles/2015/05/18/1431885721032.html
---
#### 问题描述
---
> 在写界面布局时，某控件的最后行报如下错误

	Incorrect line ending: found carriage return (\r) without corresponding newline (\n)

<!--more-->

#### 解决方法
---
> 1.  project --> clear （可以解决，但再次保存文件时又报错）
> 2.  `ctrl+a` 全选  --> `ctrl+x`剪贴  -->  `ctrl+s` 保存 --> `ctrl+v` 复制 --> `ctrl+s` 保存

---
> 注： 由于时间原因，虽然问题解决了，但是具体错误原因并未深究，欢迎交流。