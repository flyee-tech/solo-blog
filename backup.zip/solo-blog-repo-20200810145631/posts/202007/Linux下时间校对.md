title: Linux下时间校对
date: '2020-07-10 15:04:56'
updated: '2020-07-10 16:12:35'
tags: [Linux]
permalink: /articles/2020/07/10/1594364696535.html
---
# 1. 使用 `yum`安装 `ntp`插件：

```shell
yum install ntp
```

# 2. 执行命令同步时间：

```shell
ntpdate cn.pool.ntp.org
```

`cn.pool.ntp.org`是 `ntp`网络授时组织的中国授时源。
