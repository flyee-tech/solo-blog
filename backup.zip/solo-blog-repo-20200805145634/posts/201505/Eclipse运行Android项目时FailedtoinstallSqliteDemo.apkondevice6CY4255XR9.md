title: Eclipse运行Android项目时Failed to install SqliteDemo.apk on device '6CY4255XR9!
date: '2015-05-14 00:33:21'
updated: '2015-05-14 00:33:21'
tags: [Android]
permalink: /articles/2015/05/14/1431534801040.html
---
### 问题描述
---
> 今天写了一个关于Sqlite的Demo，运行项目到手机的时候安装时间很长，最后控制台报如下错误，网上查询没有解决了，写下这篇博客做一下记录。

	Failed to install SqliteDemo.apk on device '6CY4255XR9!

<!--more-->

### 解决办法
---
>1.  执行 Project-->Clear ，然后尝试运行项目。
>2.  重启Eclipse， 尝试运行
>3.  重启adb 执行：	开始-->运行-->cmd-->adb kill-server --> adb start-server
>4.  模拟器用户：删除并重启 
>5.  手机用户：重启手机