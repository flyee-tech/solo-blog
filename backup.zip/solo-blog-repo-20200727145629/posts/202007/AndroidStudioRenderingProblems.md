title: Android Studio Rendering Problems
date: '2020-07-10 15:04:55'
updated: '2020-07-10 16:15:49'
tags: [Android]
permalink: /articles/2020/07/10/1594364695148.html
---

# 问题描述

```

	Rendering Problems
	Missing styles. 
	Is the correct theme chosen for this layout?  Use the Theme combo box above the layout to choose a different layout, or fix the theme style references.  
	Failed to find style 'textViewStyle' in current theme 
	(4 similar errors not shown)

```

# 解决办法

![第一步](http://img.blog.csdn.net/20150420131805259)

![第二步](http://img.blog.csdn.net/20150420131827053)
