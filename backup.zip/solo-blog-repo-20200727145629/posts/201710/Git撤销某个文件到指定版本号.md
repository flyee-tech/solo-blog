title: Git撤销某个文件到指定版本号
date: '2017-10-16 22:55:45'
updated: '2017-10-16 22:55:45'
tags: [Git]
permalink: /articles/2017/10/16/1508165745042.html
---
1. 撤销文件到更新到index中
```shell
git reset {version_id} {path}
```
2. 提交
```shell
git commit
```
3. 检出到工作区
```shell
git checkout {file}
```
4. 提交到远程库
```shell
git push origin XXX
```