title: IDEA CodeGlance插件不显示无效不起作用的解决方案
date: '2019-10-31 23:45:53'
updated: '2019-10-31 23:45:53'
tags: [IDEA]
permalink: /articles/2019/10/31/1572536753099.html
---
1. 首先查看是否安装成功，并且插件处于开启状态。
2. 使用快捷键 `ctrl + shift + G` 或者 `cmd + shift + G`，查看是否有效果。
3. 如果还不行，点击菜单 ` IntelliJ IDEA > Preferences` ，`Other Settings > CodeGlance`，把其中 `Disabled` 选项对勾去掉。如下图。

<!-- more -->

![CodeGlance](http://peierlong-blog.oss-cn-hongkong.aliyuncs.com/OLYEiP.jpg)