title: Mac下Mysql重置密码
date: '2017-06-13 00:00:00'
updated: '2017-06-13 00:00:00'
tags: [Mac]
permalink: /articles/2020/07/10/1594364698332.html
---
# step1.关闭mysql服务

方式一：直接杀进程

```shell
ps -ef | grep mysqld
kill -9 [pid]
```

方式二：设置 > MySql > Stop MySql Server

# step2.进入终端执行以下命令

```shell
cd /usr/local/mysql/bin/
sudo su
./mysqld_safe --skip-grant-tables &
```

ps: 此时、mysql已经启动

# step3.输入命令进入mysql交互环境

```shell
./mysql
```

# step4.在mysql交互环境重置密码

```mysql
 FLUSH PRIVILEGES; 
 SET PASSWORD FOR 'root'@'localhost' = PASSWORD('你的新密码');
```

end!
