title: Effective Java思维导图
date: '2020-07-10 15:04:57'
updated: '2020-07-10 15:04:57'
tags: [Java, 脑图]
permalink: /articles/2020/07/10/1594364697477.html
---
![](https://b3logfile.com/bing/20200221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> Effective Java介绍了在Java编程中78条极具实用价值的经验规则，这些经验规则涵盖了大多数开发人员每天所面临的问题的解决方案。通过对Java平台设计专家所使用的技术的全面描述，揭示了应该做什么，不应该做什么才能产生清晰、健壮和高效的代码。

<!--more-->

### 本人总结的思维导图一张

![EffectiveJava](http://peierlong-blog.oss-cn-hongkong.aliyuncs.com/uPic/EffectiveJava.png)

**转载请注明出处：**

http://www.peiel.com/