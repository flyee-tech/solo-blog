title: Git大法好
date: '2015-11-17 23:13:11'
updated: '2020-07-10 17:02:28'
tags: [Git]
permalink: /articles/2015/11/17/1447773191085.html
---
![1_OY34A4uBsawmGoqpBV3UaA](http://peierlong-blog.oss-cn-hongkong.aliyuncs.com/uPic/1_OY34A4uBsawmGoqpBV3UaA.png)

看到一张总结Git的思维导图，特别清晰，就保存下来了。



![git大法好](http://peierlong-blog.oss-cn-hongkong.aliyuncs.com/uPic/git大法好.png)

> 提示：由于图片太大，可点击查看大图。
