title: Hexo 问题修复记录
date: '2019-03-13 05:37:52'
updated: '2019-03-13 05:37:52'
tags: [Hexo]
permalink: /articles/2019/03/13/1552426672013.html
---
## 安装 nvm

1. `curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.34.0/install.sh | bash`
2. 配置环境变量

<!-- more -->

## 使用 nvm 快捷安装 node

```shell
nvm install 6.17.0
```

## 报错解决

### 错误1

```
ERROR Plugin load failed: hexo-renderer-sass
```

### 解决1

使用brew安装系统 `libsass` 依赖

```shell
brew reinstall libsass
```

### 错误2

node版本与编译版本不一致导致失败

```
Error: The module '/usr/local/lib/node_modules/hexo/node_modules/dtrace-provider/build/Release/DTraceProviderBindings.node'
was compiled against a different Node.js version using
NODE_MODULE_VERSION 48. This version of Node.js requires
NODE_MODULE_VERSION 67. Please try re-compiling or re-installing
```

### 解决2

根据错误日志，查看版本号48的node版本，[点击查看链接](https://nodejs.org/zh-cn/download/releases/)

![node_verison.jpg](http://peierlong-blog.oss-cn-hongkong.aliyuncs.com/node_verison.jpg)

使用nvm安装对应版本：

```shell
nvm install 6.17.0
```

## 总结

hexo 不能使用的主要原因还是设备更换的原因，更换设备注意同步node版本，环境依赖，就不会出问题。