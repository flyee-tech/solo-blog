title: MySQL执行报错(1030, 'Got error 28 from storage engine')
date: '2020-08-11 11:29:21'
updated: '2020-08-11 11:29:57'
tags: [MySql]
permalink: /articles/2020/08/11/1597116561256.html
---
![](https://b3logfile.com/bing/20181204.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

解决方式：MySQL所在服务器磁盘空间不足，登录服务器或者找运维清理磁盘。

